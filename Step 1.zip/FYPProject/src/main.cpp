#include <Arduino.h>

const int ledPin = 23;  // Define the pin number for the LED

void setup() {
  pinMode(ledPin, OUTPUT);  // Set pin 23 as an output
  Serial.begin(921600);     // Initialize serial communication
  Serial.println("Hello from the setup");
}

void loop() {
  delay(1000);                     // Wait for 1 second
  digitalWrite(ledPin, HIGH);      // Turn on the LED on pin 23
  Serial.println("Hello from the loop");
  delay(1000);                     // Wait for another second
  digitalWrite(ledPin, LOW);       // Turn off the LED on pin 23
}